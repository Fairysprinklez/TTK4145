ELEVATOR PROJECT TTK4145 @NTNU Spring 2017

The purpose of this program is to run the same code on 3 computers simultaneously, in a "everyone-knows-everything" network.
